/* TODO: * Declare a Team class with the following properties:
*         o    name – String
*         o    wins – Integer
*         o    losses – Integer
*         o    winningPercent - Read-only property with getter that returns percentage of wins as a Float
*/

/*    * TODO:
      *  The class should have a constructor that requires a name argument but assigns wins and losses with 0 if not specified.
      *  The class should have a toString() method that returns a string representation of the class. */

open class Team (var name : String, var wins: Int = 0, var losses: Int=0)
{
    val winningPercent get() = winsPer()

    fun winsPer():Float{
        if(wins == 0)
        {
            return wins.toFloat()
        } else {
            return ( wins.toFloat()  / ( wins + losses ))
        }
    }

    override fun toString (): String {
        return "Team(name='$name', wins=$wins, losses=$losses)"
    }

}

/*   * TODO: Declare a SportType enum class with the following enum constants:
          BASEBALL, BASKETBALL, FOOTBALL, SOCCER, TENNIS, UNKNOWN, VOLLEYBALL.
*/
enum class SportType {
    BASEBALL, BASKETBALL, FOOTBALL, SOCCER, TENNIS, UNKNOWN, VOLLEYBALL
}

/*   * TODO: Declare the following interface:
*/
interface SportingEvent  {
    var location: String
    var sportType: SportType
}

/*   * TODO: Declare a Game class that implements SportingEvent. The class should contain the following properties:
     *   o homeTeam - Team that can be null
     *   o visitingTeam - Team that can be null
     *   o location - String that is initially empty
     *   o sportType - SportType that is initially UNKNOWN
     *   o homeScore - Integer that is initially 0
     *   o visitingScore - Integer that is initially 0
     *   o score - Read-only property with getter that returns a string containing the team
        names and scores (home team first)
     *   o winner - Read-only property with getter that returns the Team with the larger score
        or null if tied
     *   o The class should have a constructor that takes a home team and visiting team arguments that are null if not specified.
*/
class Game (var homeTeam : Team? = null, var visitingTeam: Team? = null): SportingEvent {
    override var location: String = ""
    override var sportType: SportType = SportType.UNKNOWN
    var homeScore: Int = 0
    var visitingScore: Int = 0


    /* TODO:   Read-only property with getter that returns a string containing the team
            names and scores (home team first) */
    val score get() = scorePer()

    fun scorePer(): String {
        return "${homeTeam?.name} = $homeScore , ${visitingTeam?.name} = $visitingScore"
    }

    /* TODO: Read-only property with getter that returns the Team with the larger score
            or null if tied */
    val winner get() = teamWinner()

    fun teamWinner(): Team? {
        if (homeScore > visitingScore) {
            return homeTeam //.toString()
        } else if (homeScore < visitingScore) {
            return visitingTeam //.toString()
        } else {
            return null
        }
    }
}

fun main() {
    // TODO: TEST 'TEAM' CLASS MAIN CODE
    // Given Main Tests
    println("\n=============== TESTING TEAM CLASS =====================:")
    val team1 = Team("Harding Bisons", 11, 2)
    val team2 = Team("Ouachita Baptist") // 0 and 0 defaults
    println(team1.winningPercent) // 0.84615386
    println(team2.winningPercent) // 0.0
    println(team1) // Team(name='Harding Bisons', wins=11, losses=2)

/* My Main Test Cases */

//    val team1 = Team("Harding Bisons", 11, 2)
//    val team2 = Team("Ouachita Baptist") // 0 and 0 defaults
//    println("Team 1:")
//    println(team1) // Team(name='Harding Bisons', wins=11, losses=2)
//    println("Winning %:")
//    println(team1.winningPercent) // 0.84615386
//    println("Team 2:")
//    println(team2)
//    println("Winning %:")
//    println(team2.winningPercent) // 0.0

    println("\n=============== TESTING GAME CLASS =====================:")
    // TODO: TEST 'GAME' CLASS MAIN CODE
    val game1 = Game() // null teams by default
    println(game1.score)
    val game2 = Game(team1, team2) // null = 0, null = 0
    println(game1.winner?.name) // null
    game2.location = "Searcy"
    game2.homeScore = 7
    game2.visitingScore = 6
    game2.sportType = SportType.FOOTBALL
    println(game2.score) // Harding Bisons = 7, Ouachita Baptist = 6
    println(game2.winner?.name) // Harding Bisons

}